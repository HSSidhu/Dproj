// employees.js
var faker = require('faker')
function generateEmployees () {
  var employees = []
  for (var id = 0; id < 10; id++) {
    var firstName = faker.name.firstName()
    var lastName = faker.name.lastName()
    var email = faker.internet.email()
    var phone = faker.phone.phoneNumber()
    var address = faker.address.city()
    var country = faker.address.county()
	  var date = faker.date.recent()
    employees.push({
      "id": id,
      "first_name": firstName,
      "last_name": lastName,
      "email": email,
	  "additionalProperties": [
      {
        "email": email,
        "phone": phone,
        "address": address,
        "country": country,
        "modified": date
      }
    ]
    })
  }
  return { "employees": employees }
}
module.exports = generateEmployees