// employees.js
var faker = require('faker')
function generateEmployees () {
  var employees = []
  for (var id = 0; id < 10; id++) {
    var firstName = faker.name.firstName()
    var lastName = faker.name.lastName()
    var email = faker.internet.email()
    // var phone = faker.phone.phoneNumber()
    var phone = faker.helpers.replaceSymbolWithNumber("############")
    var address = faker.address.city()
    var country = faker.address.county()
    var date = faker.date.recent()
    var random1 = faker.helpers.replaceSymbols("#?#?#?#?#????##??##?#??#") // ? is for letters and # is for numeric
    employees.push({
      "id": random1,
      "ebaId": firstName,
      "name": lastName,
      "comments": email,
	  "contact": 
      {
        "email": email,
        "phoneNumber": phone,
        "city": address,
        "addressLines": []
      }
    ,
	  "state":
      {
        "status": "Active",
        "monitored": true
      }
    ,
	  "accreditations": [ "AIS", "PIS"],
	  "nationalAccreditationData": 
      {
        "nationalId": "ebay2",
        "accreditations": []
      }
    ,
	 "physicalContacts":[]
    })
  }
  return { "employees": employees }
}
module.exports = generateEmployees