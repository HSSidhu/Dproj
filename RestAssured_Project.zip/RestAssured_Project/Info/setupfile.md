https://dzone.com/articles/running-apache-kafka-on-windows-os

also refer if required :
https://constellation.soprasteria.com/confluence2/pages/viewpage.action?spaceKey=DEP&title=How+to+launch+MS+in+local+environment

