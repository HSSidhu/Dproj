package cucumbertests;

import com.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import io.restassured.RestAssured;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;

//"src/test/resources/featuresfiles/PostRequest.feature"

@CucumberOptions(
//        strict = true,
        features = {"src/test/resources/featuresfiles/GetAllLocalHostData.feature"},
        glue = {"glue"},
//        tags = {"@smoke, @regression, @functional"},
        plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/parallel-reports/executeAllfeatures.html"},
        monochrome = false,
        format = {"pretty",
                "html:target/site/cucumber-pretty",
                "rerun:target/rerun.txt",
                "json:target/cucumber1.json"}
     )
public class executeAllfeatures extends AbstractTestNGCucumberTests {

//public static Scenario scenario;

     @Before
     public static void setUp() {

//        RestAssured.baseURI = "http://localhost:3004";
          RestAssured.baseURI = "http://localhost:80/api";
     }

    @AfterClass
    public static void afterClass(){
      Reporter.loadXMLConfig(new File("reports/extent-xml/extent-config.xml"));
        Reporter.setSystemInfo("OS", System.getProperty("os.name"));
        Reporter.setSystemInfo("Project Name", "Sopra Steria Project");
        Reporter.setSystemInfo("Environment", "QA - demo");
        Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
        Reporter.setSystemInfo("User Time zone", System.getProperty("user.timezone"));
        Reporter.setTestRunnerOutput("This is rest services report");
    }
}