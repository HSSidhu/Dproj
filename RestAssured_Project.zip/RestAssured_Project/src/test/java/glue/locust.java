package glue;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;

public class locust {
    @Given("^I am able to access locust$")
    public void iAmAbleToAccessLocust() throws Throwable {


    }
}
