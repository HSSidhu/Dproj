package com.steps;

import com.pages.newUserPage;
import com.base.BaseUtil;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ScotlandLogin {

    private BaseUtil base;
    public ScotlandLogin(BaseUtil base) {
        this.base = base;
    }


    @Given("^I have successfully accessed visit Scotland page$")
    public void iHaveSuccessfullyAccessedVisitScotlandPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        newUserPage newuser = new newUserPage(base.automationDriver);
        newuser.CreateNewAccount();
    }

    @Given("^I register new user$")
    public void iRegisterNewUser() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I have provided all required details$")
    public void iHaveProvidedAllRequiredDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^new user should be able to login using theie details$")
    public void newUserShouldBeAbleToLoginUsingTheieDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("^I have the required login details$")
    public void iHaveTheRequiredLoginDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I login using  provided all required details$")
    public void iLoginUsingProvidedAllRequiredDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }
}
