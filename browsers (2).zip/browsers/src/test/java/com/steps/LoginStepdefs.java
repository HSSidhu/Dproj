package com.steps;

import com.pages.LoginPage;
import com.base.BaseUtil;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepdefs {

    private  BaseUtil base;
    public LoginStepdefs(BaseUtil base) {
        this.base = base;
    }

    @Given("^I am on the home page and select the sign in button$")
    public void i_am_on_the_home_page_and_select_the_sign_in_button() throws Throwable {
        LoginPage log = new LoginPage(base.automationDriver);
        log.CreateNewAccount();
        String text = log.message.getText();
        if (text.contains("email address has already been registered")){
            System.out.println("Account NOT Created");
        }
    }

    @When("^I login using below details$")
    public void i_login_using_below_details(DataTable arg1) throws Throwable{


        // Write code here that turns the phrase above into concrete actions
//        List<User> users = new ArrayList<User>();
//        users = table.asList(User.class);
//
//        for(User user: users){
//            System.out.print("The username " +user.myuser);
//            System.out.print("The username " +user.mypassword);
//        }
//
//
//    }
//
//    public class User{
//        private String myuser;
//        private String mypassword;
//
//        public User(String userName, String password) {
//            myuser = userName;
//            mypassword = password;
//        }
    }

    @When("^I Select Dresses and casual dresses$")
    public void i_Select_Dresses_and_casual_dresses() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^only one product is made available$")
    public void only_one_product_is_made_available() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }


}
