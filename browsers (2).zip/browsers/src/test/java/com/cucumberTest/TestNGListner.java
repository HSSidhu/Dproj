package com.cucumberTest;

import org.testng.ITestNGListener;
import org.testng.ITestResult;

public class TestNGListner implements ITestNGListener {

        public void onTestFailure (ITestResult result){

    }
}
