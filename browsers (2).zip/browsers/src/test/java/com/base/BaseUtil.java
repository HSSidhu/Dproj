package com.base;

import org.openqa.selenium.WebDriver;

public class BaseUtil {

    public WebDriver automationDriver;
}


