package com.pages;

import com.helpers.generateTestData;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    generateTestData data = new generateTestData();

    @FindBy(how = How.CLASS_NAME,using = "login")
    private WebElement selectLogin;

    @FindBy(how = How.ID, using = "email_create")
    private WebElement emailID;

    @FindBy(how = How.ID, using = "SubmitCreate")
    private WebElement createAccount;

    @FindBy(how = How.ID, using = "create_account_error")
    public  WebElement message;


    public void CreateNewAccount(){
        selectLogin.click();
        emailID.sendKeys("test@test.com");
        emailID.sendKeys(data.getEmail());
        createAccount.submit();

    }

}
