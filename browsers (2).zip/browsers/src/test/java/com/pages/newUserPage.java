package com.pages;

import com.base.BaseUtil;
import com.helpers.generateTestData;
import com.helpers.readWrite;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

@SuppressWarnings("WeakerAccess")

public class newUserPage extends BaseUtil {

    public newUserPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    generateTestData data = new generateTestData();
    readWrite write = new readWrite();
    readWrite read = new readWrite();

    @FindBy(how = How.CSS, using = ".btn-pink.closebtn")
    private WebElement acceptCookies;

    @FindBy(how = How.XPATH, using = ".//*[@id='afHeaderLogin']/a/span")
    private WebElement selectLogin;

    @FindBy(how = How.CLASS_NAME, using = "btn-border-grey")
    private WebElement registerNow;

    @FindBy(how = How.ID, using = "firstnameUKI")
    private WebElement firstName;

    @FindBy(how = How.ID, using = "surnameUKI")
    public WebElement surname;

    @FindBy(how = How.ID, using = "email")
    private WebElement email;

    @FindBy(how = How.ID, using = "password")
    public WebElement password1;

    @FindBy(how = How.ID, using = "confirm-password")
    public WebElement password2;

    @FindBy(how = How.ID, using = "SQ-select-1")
    public WebElement selectSecurityQuestions;

    @FindBy(how = How.ID, using = "questionList-0-answer")
    public WebElement q1Answer;

    @FindBy(how = How.CLASS_NAME, using = "questionList-0-answer")
    public WebElement selectTick;


    public void CreateNewAccount() {

        write.writing(data.getEmail());
        acceptCookies.click();
        selectLogin.click();
        registerNow.click();
        firstName.sendKeys(data.getFirstName());
        surname.sendKeys(data.getLastName());
        email.sendKeys(data.getEmail());
        password1.sendKeys("password12");
        password2.sendKeys("password12");

        selectSecurityQuestions.click();
        Select select = new Select(selectSecurityQuestions);
        select.selectByIndex(1);
        q1Answer.sendKeys("Spiderman");

        for (String data : read.reading()){
            System.out.println(data);
        }


    }

}
