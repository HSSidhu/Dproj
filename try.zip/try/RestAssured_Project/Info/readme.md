dto -- data transfer object

2) Added a new class AddProp, which has all the properties of the next LIST class. Passed the same to


3)

for fake API server : read https://github.com/typicode/json-server

Step 1- Install NodeJS
----------------------
Step 2- Instal json Server :
----------------------
npm install -g json-server

Step 3- create JSON file - This will be the database
----------------------
Create a db.json file

Step 4- Start JSON Server where "db.json" file has been created:
----------------------
json-server --watch db.json

URL details
----------

GET    /posts
GET    /posts/1
POST   /posts
PUT    /posts/1
PATCH  /posts/1
DELETE /posts/1


4) You can create data using the FAKER module of JAVA.Refer article

https://medium.com/codingthesmartway-com-blog/create-a-rest-api-with-json-server-36da8680136d

refer to "testdata\JsonDB\node_modules" folder.. this will hekp you create test data as you want.. no matter how
complex the. Main queries
( Note - To amend employee.js - java script you have to use "VISUAL STUDIO CODE". It does not work perfectly but good
enough to amend the code. Use API methods given under "https://github.com/marak/Faker.js/" to see what function does
what )

Use Step 4 for accessing database but when you want to create data use below query

json-server employees.js  --> to create data as per employee.JS

5)
http://localhost:3000/employees?first_name=Arlene&last_name=Stamm
http://localhost:3000/employees?first_name=Emory&last_name=Bernier

6) refer to this link for some more details as how this is done
https://www.ontestautomation.com/selecting-response-elements-with-gpath-in-rest-assured/

7) refer this link for POJO
http://www.jsonschema2pojo.org/

8) mvn clean verify -Dtest=dummy -DfailIfNoTests=false -Dcucumber.options="--tags @red"

9)
mvn clean verify -Dcucumber.options="--tags @get
mvn clean verify -Dcucumber.options="--tags @post

10) Issue 1 : when we are using "custom template", and "parallel execution" then we need to ensure that below is updated in POM file as the place where you have stored your step defintions
 <glue>
    <package>glue</package>
 </glue>


11) to start JSON SERVER

json-server tppManagement.js --port 3004   --> Will create Random Data every time
json-server --watch tppMgmt.json --port 3004  --> compy paste the output from above result in "tppmgmt.json" and then execute the query



