RestAssured.
given()
.contentType(ContentType.JSON)
                                    // Expected condition - Start
.expect()
.body("addtionap.last_name",hasItem("Walsh")) // This will check if we have any data with WALSH as lastname and will bring out
                                    // all data. No filter. Just checks if this name is present or not
                                    // Expected condition - End
.when()
.request(Method.GET, GetURL)
.then()
.statusCode(200)
.extract()
.as(JsonFields_Demo[].class);
*******************************************************************************

RestAssured.
given()
.contentType(ContentType.JSON)
                            //Expected condition - Start
.expect()                   //Will bring out only those records that have last_name as "Walsh"
.with()                     //
.param("last_name", "Walsh")
                            //Expected condition - End
.when()
.request(Method.GET, GetURL)
.then()
.statusCode(200)
.extract()
.as(JsonFields_Demo[].class);


refer this tutorial
*******************************************************************************
http://www.mkyong.com/java/how-do-convert-java-object-to-from-json-format-gson-api/

NOTE : '[' would indicate the start of a Json Array not a Json object.

 "accreditations": ["AIS","PIS"]

 faker.helpers.replaceSymbolWithNumber("###-####"); //returns "833-6942"
 faker.helpers.replaceSymbols("???-????"); //returns "ABC-XRFD"