1) when configuring the server we have to give mongo.exe path on the Mongo Explorere

2) Watch this video
https://www.youtube.com/watch?v=mjfje33Be3g

3) Environment variable set as "C:\Program Files\MongoDB\Server\4.0\bin"
So, to start the server we have to say "mongod". this will start mongod.exe

4)CTR+Enter to run command in Mongo Shell or use PLAY button
5)From command prompt, type Mongo to enter into Mongo command line. and use EXIT to come out
6)Use JSON generator to create dummy JSON data

7) Refer https://www.youtube.com/watch?v=ynPAkZyH3R8


=========================================================================
For working with JAVA code , we have to download an external JAR file for "MongoDB Java Driver » 3.6.3"
and then add this JAR file to the project. This will then enable


=========================================================================
                                COMMANDS
=========================================================================

Use Data from below : https://github.com/buckyroberts/Source-Code-from-Tutorials/tree/master/Other/SampleJsonData
---------------------------------------------------------------------------
Databases --> collections

0) show dbs  --> will list all databases
1) use hockey  --> will create new database if not there
2) db.dropDatabase()  --> u will have to use step 1
3) INSERT ( should go as collection
4) db.players.insert() --> This will look for collections called "players" and if it does not exist, it will create on the fly. this "players" collection is the one were we will dump all playerdata

db.players.insert(
      {
         "position":"Right Wing",
         "id":8465166,
         "weight":200,
         "height":"6' 0\"",
         "imageUrl":"http://1.cdn.nhle.com/photos/mugs/8465166.jpg",
         "birthplace":"Seria, BRN",
         "age":37,
         "name":"Craig Adams",
         "birthdate":"April 26, 1977",
         "number":27
      }
	)

5) db.players.insert([]) --> Square brackets means that we can add more than one item (as above)


example :

db.players.insert([

  {
         "position":"Right Wing",
         "id":8475761,
         "weight":195,
         "height":"6' 2\"",
         "imageUrl":"http://1.cdn.nhle.com/photos/mugs/8475761.jpg",
         "birthplace":"Gardena, CA, USA",
         "age":23,
         "name":"Beau Bennett",
         "birthdate":"November 27, 1991",
         "number":19
      },
      {
         "position":"Left Wing",
         "id":8471260,
         "weight":202,
         "height":"6' 1\"",
         "imageUrl":"http://3.cdn.nhle.com/photos/mugs/8471260.jpg",
         "birthplace":"Meadow Lake, SK, CAN",
         "age":29,
         "name":"Blake Comeau",
         "birthdate":"February 18, 1986",
         "number":17
      },
      {
         "position":"Center",
         "id":8471675,
         "weight":200,
         "height":"5' 11\"",
         "imageUrl":"http://3.cdn.nhle.com/photos/mugs/8471675.jpg",
         "birthplace":"Cole Harbour, NS, CAN",
         "age":27,
         "name":"Sidney Crosby",
         "birthdate":"August 07, 1987",
         "number":87
      }
])


6) show collections
7) db.players.find()
8) db.players.find().pretty()
9) db.players.findOne()

10) REMOVE remove Databases
db.players.remove(

)

11)UPDATE -- This uses 2 parameters (

Parameter 1 -> Uniquely identifies the element to update
Parameter 2 -> Complete list of updated record

db.players.update(
{Parameter 1},
{Parameter 2}
)


12)remove collection
db.players.drop()

13) show collections


---------------

/*Find some specific information*?
14) db.players.find(
{"position": "Goalie"}

15) db.players.find(
{"position": "Goalie", "age":21}  ** AND Condition

16) OR Condition

db.players.find(
{$or:[
{"position": "Goalie", "age":21},
{"position": "Goalie", "age":31}
]
}
)

17)Find all players greater than 21 age
db.players.find(
{"age":{$gt:21}}

18) This will ONLY return the NAME of the Player ( 1 means TRUE)

By default it returns the unique ID but saying _id=0 , means do not display the ID in results

 db.players.find(
{"position": "Goalie"},
{"name":1, _id:0}
)


19) If the find query returns more records, we can use the LIMIT option to define as how many we need to display

 db.players.find(
{"position": "Goalie"},
{"name":1, _id:0}
).limit(3)

20) If the find query returns more records, we can use the SKIP option to skip first number of . Below example will skip first 2 results

 db.players.find(
{"position": "Goalie"},
{"name":1, _id:0}
).skip(2)


