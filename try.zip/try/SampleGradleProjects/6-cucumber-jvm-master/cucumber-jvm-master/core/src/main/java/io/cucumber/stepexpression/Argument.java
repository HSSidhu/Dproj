package io.cucumber.stepexpression;

public interface Argument {

    Object getValue();

}
