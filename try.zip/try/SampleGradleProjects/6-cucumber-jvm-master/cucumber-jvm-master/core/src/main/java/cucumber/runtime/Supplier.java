package cucumber.runtime;

public interface Supplier<T> {

    T get();

}
