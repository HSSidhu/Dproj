package cucumber.runtime.snippets;

public interface Concatenator {
    String concatenate(String[] words);
}
