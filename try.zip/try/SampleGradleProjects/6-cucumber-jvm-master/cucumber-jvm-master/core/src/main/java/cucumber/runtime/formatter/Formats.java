package cucumber.runtime.formatter;

public interface Formats {
    Format get(String key);

    String up(int n);
}
