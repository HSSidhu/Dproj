package cucumber.api.java8;

public interface HookNoArgsBody {
    void accept() throws Throwable;
}
