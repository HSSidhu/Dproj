# Using Cucumber Guice

The package documentation contains detailed instructions for using Cucumber Guice. In particular be sure to read the 
migration section if upgrading from earlier versions of Cucumber Guice.


[Read package documentation online at api.cucumber.io](https://github.com/cucumber/api.cucumber.io)

[Read package documentation offline (raw html)](src/main/java/cucumber/api/guice/package.html)
