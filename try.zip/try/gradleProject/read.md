Command to run the task
Gradle runInSequence